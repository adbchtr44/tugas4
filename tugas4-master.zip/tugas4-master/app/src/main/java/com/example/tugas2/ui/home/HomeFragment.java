package com.example.tugas2.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.widget.Toast;

import com.example.tugas2.AdapterPahlawan;
import com.example.tugas2.DataPahlawan;
import com.example.tugas2.DetailActivity;
import com.example.tugas2.MainActivity;
import com.example.tugas2.ModelPahlawan;
import com.example.tugas2.R;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private RecyclerView rvPahlawan;
    private ArrayList<ModelPahlawan> listPahlawan = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_home, container, false);

        rvPahlawan = root.findViewById(R.id.rv_pahlawan);
        rvPahlawan.setHasFixedSize(true);
        listPahlawan.addAll(DataPahlawan.getListData());

        recyclerView();
        return root;
    }

    private void recyclerView() {
        rvPahlawan.setLayoutManager(new LinearLayoutManager(getContext()));
        final AdapterPahlawan adapterPahlawan = new AdapterPahlawan(getContext());
        adapterPahlawan.setListPahlawan(listPahlawan);
        rvPahlawan.setAdapter(adapterPahlawan);

        adapterPahlawan.setOnItemClickCallback(new AdapterPahlawan.OnItemClickCallback() {
            @Override
            public void onItemClicked(ModelPahlawan pahlawan) {
                Toast.makeText(getContext(), "Memilih "+pahlawan.getHeroName(),Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(), DetailActivity.class);
                intent.putExtra(DetailActivity.EXTRA_DATA,pahlawan);
                startActivity(intent);
            }
        });
    }
}
